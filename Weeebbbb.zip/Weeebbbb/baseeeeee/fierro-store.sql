--categoria
create table fierro_store.categories(
id_category serial,
name_category varchar(255) not null,
descrition_category text,
CONSTRAINT pk_categories PRIMARY KEY (id_category)
)
--productos
create table fierro_store.product(
id_product serial,
id_category int not null,
name_product varchar(255) not null,
descrition_product TEXT,
price_product DECIMAL(10, 2) not null,
stock_product INT not null,
CONSTRAINT pk_product PRIMARY KEY (id_product),
CONSTRAINT fk_category FOREIGN KEY (id_category) REFERENCES fierro_store.categories(id_category)
)
--usuario
create table fierro_store.user(
id_user serial,
name_user varchar(50) not null,
email_user varchar(100) not null,
password_user varchar(100) not null,
CONSTRAINT pk_user PRIMARY KEY (id_user)
)
--pedido 
create table fierro_store.order(
id_order serial, 
id_user INT not null,
date_order DATE not null,
total_order decimal(10, 2) not null,
CONSTRAINT pk_order PRIMARY KEY (id_order),
CONSTRAINT fk_user FOREIGN KEY (id_user) REFERENCES fierro_store.user (id_user)
)
--detalle de pedido
create table fierro_store.order_detail(
id_ord_detail serial,
id_order INT not null,
id_product INT not null,
quantity_product INT not null,
price_unitary decimal(10, 2) not null,
CONSTRAINT pk_order_detail PRIMARY KEY (id_ord_detail),
CONSTRAINT fk_order FOREIGN KEY (id_order) REFERENCES fierro_store.order(id_order),
CONSTRAINT fk_product FOREIGN KEY (id_product) REFERENCES fierro_store.product(id_product)
)