import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Category } from './domain/entities/category.entity';
import { Repository } from 'typeorm';
import { CreateCategoryDto } from './interfaces/dtos/create-category.dto';
import { UpdateCategoryDto } from './interfaces/dtos/update-category.dto';

@Injectable()
export class CategoryService {
  constructor(
    @InjectRepository(Category)
    private readonly categoryRepository: Repository<Category>,
  ) {}

  async create(createCategoryDto: CreateCategoryDto): Promise<Category> {
    const category = this.categoryRepository.create(createCategoryDto);
    return await this.categoryRepository.save(category);
  }

  async findAll(): Promise<Category[]> {
    return await this.categoryRepository.find();
  }

  async findById(id_category: number): Promise<Category> {
    const category = await this.categoryRepository.findOneBy({ id_category });
    if (!category) throw new Error('Categoría no encontrada');
    return category;
  }

  async update(id_category: number, updateCategoryDto: UpdateCategoryDto): Promise<Category> {
    const category = await this.categoryRepository.findOneBy({ id_category });
    if (!category) throw new Error('Categoría no encontrada');
    if (updateCategoryDto.name_category !== undefined) {
      category.name_category = updateCategoryDto.name_category;
    }
    if (updateCategoryDto.descrition_category !== undefined) {
      category.descrition_category = updateCategoryDto.descrition_category;
    }
    return await this.categoryRepository.save(category);
  }

  async delete(id_category: number): Promise<void> {
    const result = await this.categoryRepository.delete(id_category);
    if (result.affected === 0) throw new Error('Categoría no encontrada');
  }
}