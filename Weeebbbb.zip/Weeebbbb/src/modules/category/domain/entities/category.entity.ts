import { Column, Entity, PrimaryGeneratedColumn } from 'typeorm';

@Entity({ name: 'categories', schema: 'fierro_store' })
export class Category {
  @PrimaryGeneratedColumn({ name: 'id_category' })
id_category: number;

@Column({ name: 'name_category', type: 'varchar', length: 255 })
name_category: string;

@Column({ name: 'descrition_category', type: 'text', nullable: true })
descrition_category?: string;
} 
