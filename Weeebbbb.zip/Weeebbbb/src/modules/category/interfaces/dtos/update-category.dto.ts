import { IsOptional, IsString } from 'class-validator';

export class UpdateCategoryDto {
  @IsString()
  @IsOptional()
  name_category?: string;

  @IsString()
  @IsOptional()
  descrition_category?: string;
}