import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Order } from './domain/entities/order-order.entity';
import { Repository } from 'typeorm';
import { CreateOrderDto } from './interfaces/dtos/create-order.dto';
import { UpdateOrderDto } from './interfaces/dtos/update-order.dto';

@Injectable()
export class OrderService {
  constructor(
    @InjectRepository(Order)
    private readonly orderRepository: Repository<Order>,
  ) {}

  async create(createOrderDto: CreateOrderDto): Promise<Order> {
    const order = this.orderRepository.create(createOrderDto);
    return await this.orderRepository.save(order);
  }

  async findAll(): Promise<Order[]> {
    return await this.orderRepository.find();
  }

  async findById(id_order: number): Promise<Order> {
    const order = await this.orderRepository.findOneBy({ id_order });
    if (!order) throw new Error('Pedido no encontrado');
    return order;
  }

  async update(id_order: number, updateOrderDto: UpdateOrderDto): Promise<Order> {
    const order = await this.orderRepository.findOneBy({ id_order });
    if (!order) throw new Error('Pedido no encontrado');
    Object.assign(order, updateOrderDto);
    return await this.orderRepository.save(order);
  }

  async delete(id_order: number): Promise<void> {
    const result = await this.orderRepository.delete(id_order);
    if (result.affected === 0) throw new Error('Pedido no encontrado');
  }
}