import { IsDateString, IsInt, IsNumber, IsOptional } from 'class-validator';

export class UpdateOrderDto {
  @IsInt()
  @IsOptional()
  id_user?: number;

  @IsDateString()
  @IsOptional()
  date_order?: string;

  @IsNumber()
  @IsOptional()
  total_order?: number;
}