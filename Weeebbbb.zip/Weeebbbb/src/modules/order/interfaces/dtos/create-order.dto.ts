import { IsDateString, IsInt, IsNotEmpty, IsNumber } from 'class-validator';

export class CreateOrderDto {
  @IsInt()
  id_user: number;

  @IsDateString()
  date_order: string;

  @IsNumber()
  total_order: number;
}