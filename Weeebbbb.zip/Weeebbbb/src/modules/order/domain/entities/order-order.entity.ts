import { Column, Entity, PrimaryGeneratedColumn } from 'typeorm';

@Entity({ name: 'store_order', schema: 'fierro_store' }) // Cambiado
export class Order {
  @PrimaryGeneratedColumn({ name: 'id_order' })
  id_order: number;

  @Column({ name: 'id_user', type: 'int' })
  id_user: number;

  @Column({ name: 'date_order', type: 'date' })
  date_order: Date;

  @Column({ name: 'total_order', type: 'decimal', precision: 10, scale: 2 })
  total_order: number;
}