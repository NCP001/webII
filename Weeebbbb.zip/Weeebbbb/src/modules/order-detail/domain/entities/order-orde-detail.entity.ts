import { Column, Entity, PrimaryGeneratedColumn } from 'typeorm';

@Entity({ name: 'store_order_detail', schema: 'fierro_store' })
export class OrderDetail {
  @PrimaryGeneratedColumn({ name: 'id_ord_detail' })
  id_ord_detail: number;

  @Column({ name: 'id_order', type: 'int' })
  id_order: number;

  @Column({ name: 'id_product', type: 'int' })
  id_product: number;

  @Column({ name: 'quantity_product', type: 'int' })
  quantity_product: number;

  @Column({ name: 'price_unitary', type: 'decimal', precision: 10, scale: 2 })
  price_unitary: number;
}