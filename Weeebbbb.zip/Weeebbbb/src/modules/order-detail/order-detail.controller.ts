import { Controller, Get, Post, Body, Param, Put, Delete } from '@nestjs/common';
import { OrderDetailService } from './order-detail.service';
import { OrderDetail } from './domain/entities/order-orde-detail.entity';

@Controller('order-detail')
export class OrderDetailController {
  constructor(private readonly orderDetailService: OrderDetailService) {}

  @Get()
  async findAll(): Promise<OrderDetail[]> {
    return this.orderDetailService.findAll();
  }

  @Post()
  async create(@Body() dto: Partial<OrderDetail>): Promise<OrderDetail> {
    return this.orderDetailService.create(dto);
  }

  @Put(':id')
  async update(@Param('id') id: number, @Body() dto: Partial<OrderDetail>): Promise<OrderDetail> {
    return this.orderDetailService.update(id, dto);
  }

  @Delete(':id')
  async remove(@Param('id') id: number): Promise<void> {
    return this.orderDetailService.remove(id);
  }
}