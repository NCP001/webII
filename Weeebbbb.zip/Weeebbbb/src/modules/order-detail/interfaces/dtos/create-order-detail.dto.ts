import { IsInt, IsNotEmpty, IsNumber } from 'class-validator';

export class CreateOrderDetailDto {
  @IsInt()
  id_order: number;

  @IsInt()
  id_product: number;

  @IsInt()
  quantity_product: number;

  @IsNumber()
  price_unitary: number;
}