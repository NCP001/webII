import { IsInt, IsNumber, IsOptional } from 'class-validator';

export class UpdateOrderDetailDto {
  @IsInt()
  @IsOptional()
  id_order?: number;

  @IsInt()
  @IsOptional()
  id_product?: number;

  @IsInt()
  @IsOptional()
  quantity_product?: number;

  @IsNumber()
  @IsOptional()
  price_unitary?: number;
}