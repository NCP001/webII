import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { OrderDetail } from './domain/entities/order-orde-detail.entity';

@Injectable()
export class OrderDetailService {
  constructor(
    @InjectRepository(OrderDetail)
    private readonly repo: Repository<OrderDetail>,
  ) {}

  async findAll(): Promise<OrderDetail[]> {
    return this.repo.find();
  }

  async findOne(id: number): Promise<OrderDetail> {
    const detail = await this.repo.findOneBy({ id_ord_detail: id });
    if (!detail) throw new NotFoundException('OrderDetail not found');
    return detail;
  }

  async create(dto: Partial<OrderDetail>): Promise<OrderDetail> {
    const detail = this.repo.create(dto);
    return this.repo.save(detail);
  }

  async update(id: number, dto: Partial<OrderDetail>): Promise<OrderDetail> {
    const detail = await this.findOne(id);
    Object.assign(detail, dto);
    return this.repo.save(detail);
  }

  async replace(id: number, dto: Partial<OrderDetail>): Promise<OrderDetail> {
    const detail = await this.findOne(id);
    Object.assign(detail, dto);
    return this.repo.save(detail);
  }

  async remove(id: number): Promise<void> {
    const detail = await this.findOne(id);
    await this.repo.remove(detail);
  }
}