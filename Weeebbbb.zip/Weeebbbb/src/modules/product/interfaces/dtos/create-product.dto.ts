import { IsInt, IsNotEmpty, IsNumber, IsOptional, IsString } from 'class-validator';

export class CreateProductDto {
  @IsInt()
  id_category: number;

  @IsString()
  @IsNotEmpty()
  name_product: string;

  @IsString()
  @IsOptional()
  descrition_product?: string;

  @IsNumber()
  price_product: number;

  @IsInt()
  stock_product: number;
}