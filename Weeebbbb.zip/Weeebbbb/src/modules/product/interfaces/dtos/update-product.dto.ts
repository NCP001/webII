import { IsInt, IsNumber, IsOptional, IsString } from 'class-validator';

export class UpdateProductDto {
  @IsInt()
  @IsOptional()
  id_category?: number;

  @IsString()
  @IsOptional()
  name_product?: string;

  @IsString()
  @IsOptional()
  descrition_product?: string;

  @IsNumber()
  @IsOptional()
  price_product?: number;

  @IsInt()
  @IsOptional()
  stock_product?: number;
}