import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Product } from './domain/entities/product.entity';
import { Repository } from 'typeorm';
import { CreateProductDto } from './interfaces/dtos/create-product.dto';
import { UpdateProductDto } from './interfaces/dtos/update-product.dto';

@Injectable()
export class ProductService {
  constructor(
    @InjectRepository(Product)
    private readonly productRepository: Repository<Product>,
  ) {}

  async create(createProductDto: CreateProductDto): Promise<Product> {
    const product = this.productRepository.create(createProductDto);
    return await this.productRepository.save(product);
  }

  async findAll(): Promise<Product[]> {
    return await this.productRepository.find();
  }

  async findById(id_product: number): Promise<Product> {
    const product = await this.productRepository.findOneBy({ id_product });
    if (!product) throw new Error('Producto no encontrado');
    return product;
  }

  async update(id_product: number, updateProductDto: UpdateProductDto): Promise<Product> {
    const product = await this.productRepository.findOneBy({ id_product });
    if (!product) throw new Error('Producto no encontrado');
    Object.assign(product, updateProductDto);
    return await this.productRepository.save(product);
  }

  async delete(id_product: number): Promise<void> {
    const result = await this.productRepository.delete(id_product);
    if (result.affected === 0) throw new Error('Producto no encontrado');
  }
}