import { Column, Entity, PrimaryGeneratedColumn } from 'typeorm';

@Entity({ name: 'store_product', schema: 'fierro_store' }) // Cambiado
export class Product {
  @PrimaryGeneratedColumn({ name: 'id_product' })
  id_product: number;

  @Column({ name: 'id_category', type: 'int' })
  id_category: number;

  @Column({ name: 'name_product', type: 'varchar', length: 255 })
  name_product: string;

  @Column({ name: 'descrition_product', type: 'text', nullable: true })
  descrition_product?: string;

  @Column({ name: 'price_product', type: 'decimal', precision: 10, scale: 2 })
  price_product: number;

  @Column({ name: 'stock_product', type: 'int' })
  stock_product: number;
}