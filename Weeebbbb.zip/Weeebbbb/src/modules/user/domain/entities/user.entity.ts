import { Expose } from 'class-transformer';
import { Column, Entity, PrimaryGeneratedColumn } from 'typeorm';
@Entity({ name: 'user', schema: 'fierro_store' })
export class User {
    @PrimaryGeneratedColumn({ name: 'id_user' })
    @Expose()
    id_user: number;

    @Column({ name: 'name_user', type: 'varchar', length: 50 })
    @Expose()
    name_user: string;

    @Column({ name: 'email_user', type: 'varchar', length: 100 })
    @Expose()
    email_user: string;

    @Column({ name: 'password_user', type: 'varchar', length: 100 })
    @Expose()
    password_user: string;
}