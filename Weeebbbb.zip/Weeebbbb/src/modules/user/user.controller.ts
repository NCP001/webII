import { Body, Controller, Delete, Get, Param, Patch, Post, Put } from '@nestjs/common';
import { UserService } from './user.service';
import { ApiCreatedResponse, ApiNoContentResponse, ApiOkResponse, ApiParam } from '@nestjs/swagger';
import { User } from './domain/entities/user.entity';
import { CreateUserDto } from './interfaces/dtos/create-user.dto';
import { UpdateUserDto } from './interfaces/dtos/update-user.dto';

@Controller('user')
export class UserController {
  constructor(private readonly userService: UserService) {}

  @Post('register')
  @ApiCreatedResponse({ type: User, description: 'Usuario creado exitosamente' })
  async register(
      @Body() createUserDto: CreateUserDto
    ): Promise<User> {
    return this.userService.register(createUserDto);
  }

  @Get(':id')
  @ApiParam({ name: 'id', type: Number, description: 'ID del usuario' })
  @ApiOkResponse({ type: User, description: 'Usuario encontrado exitosamente' })
  async findById(
      @Param('id') id: number
    ): Promise<User> {
      return this.userService.findById(id);
  }

  @Patch(':id')
  @ApiParam({ name: 'id', type: Number, description: 'ID del usuario' })
  @ApiOkResponse({ type: User, description: 'Usuario actualizado exitosamente' })
  async update(
      @Param('id') id: number,
      @Body() updateUserDto: UpdateUserDto,
    ): Promise<User> {
      return this.userService.update(id, updateUserDto);
  }

  @Put(':id')
  @ApiParam({ name: 'id', type: Number, description: 'ID del usuario' })
  @ApiOkResponse({ type: User, description: 'Usuario reemplazado exitosamente' })
  async replace(
    @Param('id') id: number,
    @Body() createUserDto: CreateUserDto,
  ): Promise<User> {
    return this.userService.replace(id, createUserDto);
  }

  @Delete(':id')
  @ApiParam({ name: 'id', type: Number, description: 'ID del usuario' })
  @ApiNoContentResponse({ description: 'Usuario eliminado exitosamente' })
  async delete(
      @Param('id') id: number
    ): Promise<void> {
      await this.userService.delete(id);
  }
}
