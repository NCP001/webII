import { IsEmail, IsNotEmpty, IsString, MinLength } from 'class-validator';

export class CreateUserDto {
    @IsString()
    @IsNotEmpty()
    name_user: string;

    @IsEmail()
    @IsNotEmpty()
    email_user: string;

    @IsString()
    @MinLength(6)
    password_user: string;
}