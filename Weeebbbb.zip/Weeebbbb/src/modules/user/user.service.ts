import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { User } from './domain/entities/user.entity';
import { Repository } from 'typeorm';
import { CreateUserDto } from './interfaces/dtos/create-user.dto';
import { UpdateUserDto } from './interfaces/dtos/update-user.dto';

@Injectable()
export class UserService {
    constructor(
        @InjectRepository(User)
        private readonly userRepository: Repository<User>,
    ) {}

    async register(createUserDto: CreateUserDto): Promise<User> {
        const user = this.userRepository.create(createUserDto);
        return await this.userRepository.save(user);
    }

    async findById(id_user: number): Promise<User> {
        const user = await this.userRepository.findOneBy({ id_user });
        if (!user) {
            throw new Error('Usuario no encontrado');
        }
        return user;
    }

    async update(id_user: number, updateUserDto: UpdateUserDto): Promise<User> {
        const user = await this.userRepository.findOneBy({ id_user });
        if (!user) {
            throw new Error('Usuario no encontrado');
        }
        Object.assign(user, updateUserDto);
        return await this.userRepository.save(user);
    }

    async replace(id_user: number, createUserDto: CreateUserDto): Promise<User> {
        const user = await this.userRepository.findOneBy({ id_user });
        if (!user) {
            throw new Error('Usuario no encontrado');
        }
        user.name_user = createUserDto.name_user;
        user.email_user = createUserDto.email_user;
        user.password_user = createUserDto.password_user;
        return await this.userRepository.save(user);
    }

    async delete(id_user: number): Promise<void> {
        const result = await this.userRepository.delete(id_user);
        if (result.affected === 0) {
            throw new Error('Usuario no encontrado');
        }
    }
}
