import { TypeOrmModuleOptions } from '@nestjs/typeorm';
//import { User } from '../modules/user/domain/entities/user.entity';

export function typeOrmConfig(): TypeOrmModuleOptions {
    return {
        type: 'postgres',
        host: process.env.DB_HOST,
        port: Number(process.env.DB_PORT),
        username: process.env.DB_USER,
        password: process.env.DB_PASSWORD,
        database: process.env.DB_NAME,
        schema: process.env.DB_SCHEMA,
        entities: [__dirname + '/../modules/**/*.entity.{js,ts}'], // <-- Cambia esto
        synchronize: process.env.DB_SYNCHRONIZE === 'true',
        dropSchema: process.env.DB_DROP_SCHEMA === 'true',
    };
}
